package org.example.tutorial;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class SimulateOneDay {
    class Customer {
        int type;
        double arrivalTime;
        double les;
        int nbServeurs;
        double waitingTime;
        int qLength;
        // Savoir la case qui est réservé à chaque type
        int[] tableau = new int[27];
    }

    public void createDayCustomers(String dayFile) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(dayFile));
        String readedLine = br.readLine();
        while(readedLine != null){
            Customer customer = new Customer();
            customer.type = Integer.parseInt(readedLine.split(",")[1]);
            customer.arrivalTime = getTime(readedLine.split(",")[0]);
        }
    }
    public double getTime(String s){
        String s1 = s.split(" ")[1];
        return Integer.parseInt(s1.split(":")[0])*3600
                +Integer.parseInt(s1.split(":")[1])*60
                +Integer.parseInt(s1.split(":")[2])-(8*3600);
    }
}
